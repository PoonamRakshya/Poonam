package com.capgemini.CustomerManagementSystem.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CustomerDAOImplementationTest {
	

	@Test
	void testAddCustomer() {
		fail("Not yet implemented");
	}

	@Test
	void testDisplayAccount() {
		fail("Not yet implemented");
	}

	@Test
	void testDeposit() {
		fail("Not yet implemented");
	}

	@Test
	void testWithdraw() {
		fail("Not yet implemented");
	}

	@Test
	void testFundTransfer() {
		fail("Not yet implemented");
	}

	@Test
	void testPrintTransactions() {
		fail("Not yet implemented");
	}

	@Test
	void testAddTransaction() {
		fail("Not yet implemented");
	}

}
