package com.capgemini.CustomerManagementSystem.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.CustomerManagementSystem.dao.CustomerDAOImplementation;
import com.capgemini.CustomerManagementSystem.entity.Account;
import com.capgemini.CustomerManagementSystem.entity.Transaction;
import com.capgemini.CustomerManagementSystem.exception.BankManagementException;

class CustomerDAOImplementationTest {
	CustomerDAOImplementation dao=null;
	Account acc1,acc2=null;
	Transaction trans,trans1=null;

	@Test
	public void testCreatAccount() throws BankManagementException{
	
 	dao=new CustomerDAOImplementation();
	//acc1.setAccountNumber(987456L);
	acc1.setCname("Poonam");
	acc1.setAge(21);
	acc1.setAddress("Chennai");
	acc1.setBalance(2000.0);
	acc1.setPhoneNo("9840308957");
	acc1.setEmailId("poonam@gmail.com");

	boolean no= dao.addCustomer(acc1);
	assertTrue(true);

	dao=new CustomerDAOImplementation();
	acc2.setAccountNumber(482736L);
	acc2.setCname("Eunice");
	acc2.setAge(23);
	acc2.setAddress("Tuticorin");
	acc2.setBalance(7000.0);
	acc2.setPhoneNo("9994236350");
	acc2.setEmailId("eunice@gmail.com");

	boolean no2= dao.addCustomer(acc2);
	assertTrue(true);
	}
	
	@Test
	void testDisplayAccount()  throws BankManagementException {
		dao=new CustomerDAOImplementation();
		Account a= dao.displayAccount(482736L);
		Double bal = a.getBalance();
		assertEquals(7000.0,bal,0);
	}

	@Test
	void testDeposit()  throws BankManagementException{
		dao=new CustomerDAOImplementation();
		Account a= dao.displayAccount(482736L);
		Double bal = a.getBalance();
		assertEquals(7000.0,bal,0);
		
	}
	@Test
	void testWithdraw() throws BankManagementException {
		dao=new CustomerDAOImplementation();
		Account a= dao.displayAccount(482736L);
		Double bal = a.getBalance();
		assertEquals(7000.0,bal,0);
		
	}

	@Test
	void testFundTransfer() throws BankManagementException {
		dao=new CustomerDAOImplementation();
		Account a= dao.displayAccount(482736L);
		Double bal = a.getBalance();
		assertEquals(7000.0,bal,0);
	}



	
}
