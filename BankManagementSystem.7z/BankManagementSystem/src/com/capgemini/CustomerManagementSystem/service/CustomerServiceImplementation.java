package com.capgemini.CustomerManagementSystem.service;

import java.util.List;

import com.capgemini.CustomerManagementSystem.dao.CustomerDAOImplementation;
import com.capgemini.CustomerManagementSystem.entity.Account;
import com.capgemini.CustomerManagementSystem.entity.Transaction;
import com.capgemini.CustomerManagementSystem.exception.BankManagementException;

public class CustomerServiceImplementation implements ICustomerService{
       CustomerDAOImplementation dao = new CustomerDAOImplementation();
       
       public boolean validateName(String name) throws BankManagementException{

    		if (name.matches("^[a-zA-Z]+$")) {
    			return true;

    		} else
    			System.out.println("Name should only have characters");
    		return false;
    	}


    	public boolean isValidEmailAddress(String email) throws BankManagementException{
    		String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
    		java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
    		java.util.regex.Matcher m = p.matcher(email);
    		return m.matches();
    	}


    	public boolean validateNumber(String mobile) throws BankManagementException{

    		if (mobile.matches("[0-9]{10}")) {
    			return true;

    		} else
    			System.out.println("Enter a valid mobile number");
    		return false;
    	}


    	public boolean validateAge(int age) throws BankManagementException{
    		if (age > 16 && age<100)
    			return true;
    		else
    			System.out.println("Enter valid age");
    		return false;
    	}



    	public boolean validateBalance(double balance) throws BankManagementException{
    		if (balance > 1000)
    			return true;
    		else
    			System.out.println("Balance is low, balance should be more than Rs.1000");
    		return false;
    	}


   
       
       
	@Override
	public boolean addCustomer(Account account) throws BankManagementException{
		return dao.addCustomer(account);
	}

	@Override
	public Account displayAccount(Long accountNo) throws BankManagementException{
		return dao.displayAccount(accountNo);
	}

	@Override
	public Transaction deposit(Long accountNo, Double depositAmount, Transaction transaction) throws BankManagementException{
		return dao.deposit(accountNo, depositAmount, transaction);
	}

	@Override
	public Transaction withdraw(Long accountNo, Double withdrawAmount, Transaction transaction)
			throws BankManagementException{
		return dao.withdraw(accountNo, withdrawAmount, transaction);
	}

	@Override
	public Transaction fundTransfer(Long AccountNo, Double transferAmt, Transaction transaction)
			throws BankManagementException{
		return dao.fundTransfer(AccountNo, transferAmt, transaction);
	}

	@Override
	public List<Transaction> printTransactions(Long accountNo) throws BankManagementException{
		return dao.printTransactions(accountNo);
	}



}