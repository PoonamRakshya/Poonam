package com.capgemini.CustomerManagementSystem.exception;

public class AccountNotFound extends Exception {
	
	private String status;
	
	public AccountNotFound() {
		this.status="Cant perform the transaction";
	}
	
	public AccountNotFound(String status) {
		super(status);
	}
	
	public String getStatus() {
		return this.status;
	}

	@Override
	public String toString() {
		return "EmployeeException [status=" + status + "]";
	}

}