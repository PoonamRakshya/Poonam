package com.capgemini.CustomerManagementSystem.dao;

import java.util.List;



import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import com.capgemini.CustomerManagementSystem.entity.Account;
import com.capgemini.CustomerManagementSystem.entity.Transaction;
import com.capgemini.CustomerManagementSystem.exception.AccountNotFound;
import com.capgemini.CustomerManagementSystem.utility.JPAUtil;

public class CustomerDAOImplementation implements ICustomerDAO {
	EntityManager entityManager = null;

	@Override
	public boolean addCustomer(Account account1) throws AccountNotFound {
		boolean flag = false;
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(account1);
			entityManager.getTransaction().commit();
			return flag;
		} catch (PersistenceException e) {
			throw new AccountNotFound(e.getMessage());
		} 
		
	}

	@Override
	public Account displayAccount(Long accountNo) throws AccountNotFound {
		Account account = null;
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			account = entityManager.find(Account.class, accountNo);
			return account;
		} catch (PersistenceException e) {
			throw new AccountNotFound(e.getMessage());
		} 
	}

	@Override
	public Transaction deposit(Long accountNo, Double depositAmount, Transaction transaction) throws AccountNotFound {
		Account account = null;

		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			account = entityManager.find(Account.class, accountNo);
			Double newBalance = account.getBalance() + depositAmount;
			account.setBalance(newBalance);
			transaction.setBalance(newBalance);

			entityManager.merge(account);
			entityManager.getTransaction().commit();

			Transaction transaction1 = addTransaction(transaction);

			return transaction1;
		} catch (PersistenceException e) {
			throw new AccountNotFound(e.getMessage());
		} 
	}

	@Override
	public Transaction withdraw(Long accountNo, Double withdrawAmount, Transaction transaction)
			throws AccountNotFound {
		Account account = null;
		Transaction transaction1;
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			account = entityManager.find(Account.class, accountNo);
			if (account.getBalance() - withdrawAmount > 500) {
				Double newBalance = account.getBalance() - withdrawAmount;
				account.setBalance(newBalance);
				transaction.setBalance(newBalance);
				entityManager.merge(account);
				entityManager.getTransaction().commit();

				transaction1 = addTransaction(transaction);

				return transaction1;
			} else {
				Transaction transaction2 = null;
				return transaction2;
			}
		} catch (PersistenceException e) {
			throw new AccountNotFound(e.getMessage());
		} 
	}

	@Override
	public Transaction fundTransfer(Long AccountNo, Double transferAmt, Transaction transaction)
			throws AccountNotFound {
		Account account, account1 = null;
		Transaction transaction1;
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();

			account = entityManager.find(Account.class, AccountNo);
			if (account.getBalance() - transferAmt > 500) {
				Double newBalance = account.getBalance() - transferAmt;
				account.setBalance(newBalance);
				transaction.setBalance(newBalance);

				entityManager.merge(account);

				account1 = entityManager.find(Account.class, AccountNo);
				Double newBalance1 = account1.getBalance() + transferAmt;
				account1.setBalance(newBalance1);

				entityManager.merge(account1);
				entityManager.getTransaction().commit();

				transaction1 = addTransaction(transaction);

				return transaction1;
			} else {
				Transaction transaction2 = null;
				return transaction2;
			}
		} catch (PersistenceException e) {
			throw new AccountNotFound(e.getMessage());
		} 
	}

	@Override
	public List<Transaction> printTransactions(Long accountNo) throws AccountNotFound {
		EntityManager entityManager = JPAUtil.getEntityManager();
		String jql = "select e from Transaction e where e.AccountNo=:num";
		TypedQuery<Transaction> typedQuery = entityManager.createQuery(jql, Transaction.class);
		typedQuery.setParameter("num", accountNo);
		List<Transaction> transactionList = typedQuery.getResultList();
	    return transactionList;
	}

	@Override
	public Transaction addTransaction(Transaction transaction) throws AccountNotFound {
		Transaction transaction1 = null;
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(transaction);
			entityManager.getTransaction().commit();
			transaction1 = transaction;
			return transaction1;
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new AccountNotFound(e.getMessage());
		} 
		
	}
}