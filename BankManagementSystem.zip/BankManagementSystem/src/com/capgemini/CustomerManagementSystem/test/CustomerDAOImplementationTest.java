package com.capgemini.CustomerManagementSystem.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CustomerDAOImplementationTest {
	CustomerDAOImplementation dao=null;
	Account accc1,acc2=null;
	Transaction trans,trans1=null;

	@Test
	public void testCreatAccount() throws BankManagementException{
	
 	dao=new CustomerDAOImplementation();
	acc1.setaccountNumber(987456L);
	acc1.setcname("Poonam");
	acc1.setage(21);
	acc1.setaddress("Chennai");
	acc1.setbalance(2000.0);
	acc1.phoneNo("9840308957");
	acc1.emailId("poonam@gmail.com");

	boolean no= dao.addCustomer(acc1);
	assertTrue("true",no);

	dao=new CustomerDAOImplementation();
	acc2.setaccountNumber(482736L);
	acc2.setcname("Eunice");
	acc2.setage(23);
	acc2.setaddress("Tuticorin");
	acc2.setbalance(7000.0);
	acc2.phoneNo("9994236350");
	acc2.emailId("eunice@gmail.com");

	boolean no2= dao.addCustomer(acc2);
	assertTrue("true",no2);

	
	@Test
	void testDisplayAccount()  throws BankManagementException {
		dao=new CustomerDAOImplementation();
		Account a= dao.displayAccount(482736L);
		Double bal = a.getBalance();
		assertEquals(7000.0,bal,0);
	}

	@Test
	void testDeposit()  throws BankManagementException{
		dao=new CustomerDAOImplementation();
		Account a= dao.displayAccount(482736L);
		Double bal = a.getBalance();
		assertEquals(7000.0,bal,0);
		
	}
	@Test
	void testWithdraw() {
		dao=new CustomerDAOImplementation();
		Account a= dao.displayAccount(482736L);
		Double bal = a.getBalance();
		assertEquals(7000.0,bal,0);
		
	}

	@Test
	void testFundTransfer() {
		dao=new CustomerDAOImplementation();
		Account a= dao.displayAccount(482736L);
		Double bal = a.getBalance();
		assertEquals(7000.0,bal,0);
	}



	@Test
	void testAddTransaction() {
		dao=new CustomerDAOImplementation();
		LocalDate date= LocalDate,now();
		trans.
	}

}
