package com.capgemini.CustomerManagementSystem.exception;

public class BankManagementException extends Exception {
	
	private String status;
	
	public BankManagementException() {
		this.status="Cant perform the transaction...exception has occured";
	}
	
	public BankManagementException (String status) {
		super(status);
	}
	
	public String getStatus() {
		return this.status;
	}

	@Override
	public String toString() {
		return "EmployeeException [status=" + status + "]";
	}

}